package com.xenonx.emulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val XboxGreen = Color(0xFF78C943)
private val Dark = Color(0xFF080C09)
private val Panel = Color(0xFF151D15)


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XenonXApp() }
    }
}


@Composable
fun XenonXApp() {
    var page by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = XboxGreen, background = Dark, surface = Panel)) {
        Scaffold(containerColor = Dark, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = XboxGreen) {
                listOf("Home", "Library", "Controls", "Settings").forEach { label ->
                    NavigationBarItem(
                        selected = page == label,
                        onClick = { page = label },
                        icon = {
                            Icon(when(label) {
                                "Home" -> Icons.Default.Home
                                "Library" -> Icons.Default.SportsEsports
                                "Controls" -> Icons.Default.Gamepad
                                else -> Icons.Default.Settings
                            }, contentDescription = label)
                        },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = XboxGreen,
                            selectedTextColor = XboxGreen,
                            indicatorColor = Color(0xFF263B20)
                        )
                    )
                }
            }
        }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when(page) {
                    "Home" -> HomeScreen(onLibrary = { page = "Library" })
                    "Library" -> LibraryScreen()
                    "Controls" -> ControlsScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}


@Composable
fun HomeScreen(onLibrary: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("XENONX", color = XboxGreen, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Text("Original console • Android", color = Color.LightGray)
        Box(Modifier.fillMaxWidth().height(190.dp).background(Panel, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.SportsEsports, null, tint = XboxGreen, modifier = Modifier.size(76.dp))
                Text("XenonX", fontSize = 28.sp, color = XboxGreen, fontWeight = FontWeight.Bold)
                Text("CLASSIC EMULATION PROJECT", color = Color.Gray, letterSpacing = 2.sp, fontSize = 11.sp)
            }
        }
        Button(onClick = onLibrary, colors = ButtonDefaults.buttonColors(containerColor = XboxGreen, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FolderOpen, null)
            Spacer(Modifier.width(8.dp))
            Text("OPEN GAME LIBRARY", fontWeight = FontWeight.Bold)
        }
        InfoCard("Emulation engine", "Core emulation is not included yet. This app is the UI foundation for future development.")
        InfoCard("Status", "XenonX alpha 0.1 • Android interface prototype")
    }
}


@Composable
fun LibraryScreen() {
    val entries = listOf("Game library", "No games added", "Add your legally obtained game files through a future library importer.")
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("LIBRARY", color = XboxGreen, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Icon(Icons.Default.Folder, tint = XboxGreen, modifier = Modifier.size(42.dp), contentDescription = null)
                Text(entries[1], color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(entries[2], color = Color.LightGray)
            }
        }
    }
}


@Composable
fun ControlsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TOUCH CONTROLS", color = XboxGreen, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PadButton("Y", Color(0xFFE5C94C)); PadButton("X", Color(0xFF4A91D9))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PadButton("B", Color(0xFFE16B54)); PadButton("A", Color(0xFF78C943))
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { PadButton("BACK", Color.DarkGray, wide = true); PadButton("START", Color.DarkGray, wide = true) }
        Spacer(Modifier.height(24.dp))
        Text("These are visual prototype buttons; they do not send game input yet.", color = Color.Gray)
    }
}


@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SETTINGS", color = XboxGreen, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        InfoCard("Version", "XenonX alpha 0.1")
        InfoCard("Graphics", "Graphics options will be added when an emulation core is integrated.")
        InfoCard("Controller", "Bluetooth controller support is planned for a later build.")
        InfoCard("About", "An independent Xbox-original emulation research project. No BIOS, firmware or game files are included.")
    }
}


@Composable
fun PadButton(text: String, color: Color, wide: Boolean = false) {
    Box(Modifier.size(width = if(wide) 108.dp else 64.dp, height = 64.dp).background(color, RoundedCornerShape(18.dp)).clickable { }, contentAlignment = Alignment.Center) {
        Text(text, color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = if(wide) 13.sp else 20.sp)
    }
}


@Composable
fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = XboxGreen, fontWeight = FontWeight.Bold)
            Text(body, color = Color.LightGray, fontSize = 14.sp)
        }
    }
}
